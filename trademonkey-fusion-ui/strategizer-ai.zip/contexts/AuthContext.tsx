import type React from "react"
import { createContext, useState, useContext, useEffect } from "react"
import Cookies from "js-cookie"

interface AuthContextType {
  isAuthenticated: boolean
  login: (email: string, password: string) => Promise<void>
  logout: () => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false)

  useEffect(() => {
    const token = Cookies.get("auth_token")
    if (token) {
      setIsAuthenticated(true)
    }
  }, [])

  const login = async (email: string, password: string) => {
    // Implement your actual login logic here
    // For this example, we'll just set a cookie
    Cookies.set("auth_token", "example_token", { expires: 7 }) // Expires in 7 days
    setIsAuthenticated(true)
  }

  const logout = () => {
    Cookies.remove("auth_token")
    setIsAuthenticated(false)
  }

  return <AuthContext.Provider value={{ isAuthenticated, login, logout }}>{children}</AuthContext.Provider>
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
