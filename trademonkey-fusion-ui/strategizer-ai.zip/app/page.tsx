"use client"

import Page from "../components/page"

export default function SyntheticV0PageForDeployment() {
  return <Page />
}