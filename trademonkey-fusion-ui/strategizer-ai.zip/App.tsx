import { BrowserRouter as Router, Route, Routes } from "react-router-dom"
import { AuthProvider } from "@/contexts/AuthContext"
import { Login } from "@/components/Login"
import { Register } from "@/components/Register"
import { Dashboard } from "@/components/Dashboard"
import { ProtectedRoute } from "@/components/ProtectedRoute"
import { Layout } from "@/components/Layout"

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route
            path="/*"
            element={
              <ProtectedRoute>
                <Layout>
                  <Routes>
                    <Route path="/" element={<Dashboard />} />
                    {/* Add other routes here */}
                  </Routes>
                </Layout>
              </ProtectedRoute>
            }
          />
        </Routes>
      </Router>
    </AuthProvider>
  )
}

export default App
