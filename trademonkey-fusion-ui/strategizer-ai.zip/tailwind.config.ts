import type { Config } from "tailwindcss"

const config: Config = {
  darkMode: ["class"],
  content: [
    "./pages/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./app/**/*.{ts,tsx}",
    "./src/**/*.{ts,tsx}",
    "*.{js,ts,jsx,tsx,mdx}",
  ],
  prefix: "",
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        // Custom cyberpunk colors
        cyber: {
          blue: "#00ffff",
          pink: "#ff00ff",
          green: "#00ff00",
          purple: "#8000ff",
          dark: "#0a0a14",
        },
        // Holographic colors
        holo: {
          background: "var(--holo-background)",
          glass: "var(--holo-glass)",
          border: "var(--holo-border)",
        },
        // Sidebar colors
        sidebar: {
          DEFAULT: "hsl(var(--sidebar))",
          foreground: "hsl(var(--sidebar-foreground))",
          primary: "hsl(var(--sidebar-primary))",
          "primary-foreground": "hsl(var(--sidebar-primary-foreground))",
          accent: "hsl(var(--sidebar-accent))",
          "accent-foreground": "hsl(var(--sidebar-accent-foreground))",
          border: "hsl(var(--sidebar-border))",
          ring: "hsl(var(--sidebar-ring))",
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
        "float-down": {
          from: { transform: "translateY(-100%)", opacity: "1" },
          to: { transform: "translateY(1000%)", opacity: "0" },
        },
        "cyber-glitch": {
          "0%, 100%": {
            opacity: "1",
            textShadow:
              "0 0 2px rgba(0, 255, 255, 0.8), 0 0 4px rgba(0, 255, 255, 0.6), 0 0 6px rgba(0, 255, 255, 0.4), 0 0 8px rgba(0, 255, 255, 0.2)",
          },
          "90%": { opacity: "1" },
          "91%": {
            opacity: "0.8",
            textShadow: "2px 0 0 rgba(255, 0, 255, 0.8), -2px 0 0 rgba(0, 255, 255, 0.8)",
          },
          "92%": {
            opacity: "1",
            textShadow: "0 0 2px rgba(0, 255, 255, 0.8)",
          },
          "93%": {
            opacity: "0.9",
            textShadow: "1px 0 0 rgba(255, 0, 255, 0.6), -1px 0 0 rgba(0, 255, 255, 0.6)",
          },
          "94%": { opacity: "1" },
          "95%": {
            opacity: "0.85",
            textShadow: "3px 0 0 rgba(255, 0, 255, 0.4), -3px 0 0 rgba(0, 255, 255, 0.4)",
          },
          "96%": {
            opacity: "1",
            textShadow: "0 0 2px rgba(0, 255, 255, 0.8)",
          },
        },
        "pulse-glow": {
          "0%, 100%": {
            opacity: "1",
            boxShadow: "0 0 15px rgba(0, 255, 255, 0.5)",
          },
          "50%": {
            opacity: "0.7",
            boxShadow: "0 0 25px rgba(0, 255, 255, 0.8)",
          },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        "float-down": "float-down 10s linear infinite",
        "cyber-glitch": "cyber-glitch 2s infinite alternate",
        "pulse-glow": "pulse-glow 2s infinite",
      },
      fontFamily: {
        sans: ["Inter", "sans-serif"],
        mono: ["Fira Code", "monospace"],
      },
      boxShadow: {
        "glow-sm": "0 0 10px rgba(0, 255, 255, 0.3)",
        glow: "0 0 20px rgba(0, 255, 255, 0.5)",
        "glow-lg": "0 0 30px rgba(0, 255, 255, 0.7)",
        "glow-pink": "0 0 20px rgba(255, 0, 255, 0.5)",
        "glow-green": "0 0 20px rgba(0, 255, 0, 0.5)",
      },
      backdropBlur: {
        xs: "2px",
      },
      spacing: {
        "18": "4.5rem",
        "88": "22rem",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
} satisfies Config

export default config
