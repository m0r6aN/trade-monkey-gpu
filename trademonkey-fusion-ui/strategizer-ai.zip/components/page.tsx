"use client"

import { Layout } from "@/components/layout"
import { Dashboard } from "@/components/dashboard"

export default function Page() {
  return (
    <Layout>
      <Dashboard />
    </Layout>
  )
}
