"use client"

import { motion } from "framer-motion"
import { Sidebar } from "./sidebar"
import type React from "react"

export function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="hud-container">
      <div className="hud-overlay" />
      <Sidebar />
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="ml-32 relative" // Increased left margin to accommodate centered sidebar
      >
        {children}
      </motion.div>
    </div>
  )
}
