"use client"

import { motion } from "framer-motion"
import { CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function Dashboard() {
  return (
    <div className="hud-content">
      <motion.h1
        className="text-4xl font-bold text-primary glow-text col-span-3"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        AI Command Hub
      </motion.h1>

      <motion.div
        className="col-span-3 grid gap-6 md:grid-cols-3"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
      >
        {["Neon Oracle", "Rekt Rab8", "Cipher"].map((agent, index) => (
          <motion.div
            key={index}
            className="holo-card glow-border"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
          >
            <CardHeader className="border-b border-holo-border">
              <CardTitle className="glow-text">{agent} Module</CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <p className="text-muted-foreground">Processing live data...</p>
            </CardContent>
          </motion.div>
        ))}
      </motion.div>
    </div>
  )
}
