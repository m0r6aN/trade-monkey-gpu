"use client"

import { useEffect, useState } from "react"
import { FileUpload } from "@/components/FileUpload"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { getFiles } from "@/api/file"
import { useToast } from "@/hooks/useToast"
import { motion } from "framer-motion"

interface File {
  _id: string
  originalname: string
  size: number
  uploadDate: string
}

export function FileManagement() {
  const [files, setFiles] = useState<File[]>([])
  const { toast } = useToast()

  useEffect(() => {
    fetchFiles()
  }, [])

  const fetchFiles = async () => {
    try {
      const fetchedFiles = await getFiles()
      setFiles(fetchedFiles)
      console.log("Successfully fetched training files")
    } catch (error) {
      console.error("Error fetching training files:", error)
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message,
      })
    }
  }

  const handleUpload = async () => {
    await fetchFiles() // Refresh file list after upload
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="p-6 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-950 via-background to-background min-h-screen"
    >
      <Card className="cyber-card bg-blue-950/40 backdrop-blur-md border-cyan-500/30">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-center text-cyan-500 cyber-glitch">TRAINING FILES</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <FileUpload onUpload={handleUpload} />

          <div className="mt-4">
            <h3 className="text-lg font-semibold mb-2 text-cyan-400">Uploaded Files</h3>
            <div className="space-y-2">
              {files.map((file) => (
                <motion.div
                  key={file._id}
                  className="p-3 border border-cyan-800 rounded bg-blue-950/60 text-cyan-300"
                  whileHover={{ scale: 1.02, boxShadow: "0 0 15px rgba(0, 255, 255, 0.3)" }}
                >
                  <p className="font-medium">{file.originalname}</p>
                  <p className="text-sm text-cyan-500">
                    Size: {Math.round(file.size / 1024)} KB | Uploaded: {new Date(file.uploadDate).toLocaleDateString()}
                  </p>
                </motion.div>
              ))}
              {files.length === 0 && <p className="text-cyan-500">No files uploaded yet</p>}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}
