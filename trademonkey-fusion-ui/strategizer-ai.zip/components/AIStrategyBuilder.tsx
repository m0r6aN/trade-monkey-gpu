"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { buildStrategy } from "@/api/strategy"
import { uploadFile, getFiles } from "@/api/file"
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter"
import { dracula } from "react-syntax-highlighter/dist/esm/styles/prism"
import type { Conversation, StrategyRequest } from "@/lib/types/messaging"
import { Modal } from "@/components/Modal"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Upload, FileText, Bot, Code, PlayCircle, Zap } from "lucide-react"
import { GlowCard } from "@/components/GlowCard"
import { MascotHeader } from "@/components/MascotHeader"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

type CustomFile = {
  id: string
  name: string
  url: string
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { duration: 0.5 } },
}

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
}

const glowVariants = {
  idle: {
    scale: 1,
    boxShadow: "0 0 0 0 rgba(0, 0, 0, 0)",
  },
  hover: {
    scale: 1.05,
    boxShadow: "0 0 10px 5px rgba(0, 255, 255, 0.5)",
    transition: { duration: 0.2 },
  },
}

export function AIStrategyBuilder() {
  const [file, setFile] = useState<CustomFile | null>(null)
  const [files, setFiles] = useState<CustomFile[]>([])
  const [isGlobal, setIsGlobal] = useState(false)
  const [strategyInput, setStrategyInput] = useState("")
  const [startingEquity, setStartingEquity] = useState(10000)
  const [maxIterations, setMaxIterations] = useState(100)
  const [strategy, setStrategy] = useState("")
  const [messages, setMessages] = useState<Conversation[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [userApprovalNeeded, setUserApprovalNeeded] = useState(false)
  const [approvalData, setApprovalData] = useState<any>(null)

  useEffect(() => {
    const fetchFiles = async () => {
      const fetchedFiles = await getFiles()
      setFiles(fetchedFiles)
    }
    fetchFiles()
  }, [])

  const handleFileUpload = async () => {
    if (file) {
      setIsLoading(true)
      await uploadFile(file, isGlobal)
      setIsLoading(false)
      setFile(null)
      const fetchedFiles = await getFiles()
      setFiles(fetchedFiles)
    }
  }

  const handleBuildStrategy = async () => {
    setIsLoading(true)
    const request: StrategyRequest = {
      strategyDescription: strategyInput,
      startingEquity: startingEquity,
      maxIterations: maxIterations,
    }
    try {
      const response = await buildStrategy(request)
      setStrategy(response.strategy)
      setMessages(response.conversation)
      if (response.userApprovalNeeded) {
        setUserApprovalNeeded(true)
        setApprovalData(response.approvalData)
      }
    } catch (error) {
      console.error("Error building strategy:", error)
      // Handle error appropriately, e.g., display an error message to the user
    } finally {
      setIsLoading(false)
    }
  }

  const handleBacktest = () => {
    // Implement backtesting logic here
    console.log("Backtesting strategy:", strategy)
  }

  return (
    <motion.div
      className="min-h-screen bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-950 via-background to-background text-cyan-300"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      <div className="container mx-auto p-6 space-y-6">
        <MascotHeader variant="strategizer" title="AI Strategy Builder" subtitle="Powered by Strategizer Bunny AI" />

        <motion.div className="grid grid-cols-1 md:grid-cols-2 gap-6" variants={containerVariants}>
          {/* File Upload Section */}
          <motion.div variants={itemVariants}>
            <GlowCard variant="strategizer" glowIntensity="low" className="cyber-card">
              <motion.div
                className="flex items-center gap-2 mb-4"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Upload className="h-5 w-5 text-cyan-500" />
                <h2 className="text-lg font-semibold text-cyan-400">Upload Training Data</h2>
              </motion.div>
              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Input
                    type="file"
                    onChange={(e) => {
                      const selectedFile = e.target.files?.[0]
                      if (selectedFile) {
                        setFile({
                          id: selectedFile.name,
                          name: selectedFile.name,
                          url: URL.createObjectURL(selectedFile),
                        })
                      } else {
                        setFile(null)
                      }
                    }}
                    className="cyber-input"
                  />
                  <Button onClick={handleFileUpload} disabled={isLoading} className="cyber-button">
                    <Upload className="mr-2 h-4 w-4" />
                    Upload
                  </Button>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="isGlobal"
                    checked={isGlobal}
                    onCheckedChange={(checked) => setIsGlobal(checked as boolean)}
                  />
                  <Label htmlFor="isGlobal" className="text-cyan-300">
                    Make file global
                  </Label>
                </div>
              </div>
            </GlowCard>
          </motion.div>

          {/* Existing Files Section */}
          <motion.div variants={itemVariants}>
            <GlowCard variant="strategizer" glowIntensity="low" className="cyber-card">
              <motion.div
                className="flex items-center gap-2 mb-4"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <FileText className="h-5 w-5 text-cyan-500" />
                <h2 className="text-lg font-semibold text-cyan-400">Existing Files</h2>
              </motion.div>
              <ScrollArea className="h-[200px] rounded-md border border-cyan-800">
                {files.map((file: CustomFile) => (
                  <div key={file.id} className="flex items-center justify-between p-2 hover:bg-cyan-900/30">
                    <span className="text-cyan-300">{file.name}</span>
                  </div>
                ))}
              </ScrollArea>
            </GlowCard>
          </motion.div>
        </motion.div>

        {/* Strategy Request Input */}
        <motion.div variants={itemVariants}>
          <GlowCard variant="strategizer" glowIntensity="medium" className="cyber-card">
            <motion.div
              className="flex items-center gap-2 mb-4"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Zap className="h-5 w-5 text-cyan-500" />
              <h2 className="text-lg font-semibold text-cyan-400">Strategy Request</h2>
            </motion.div>
            <div className="space-y-4">
              <Textarea
                placeholder="Describe your trading strategy..."
                value={strategyInput}
                onChange={(e) => setStrategyInput(e.target.value)}
                className="cyber-input min-h-[100px]"
              />
              <div className="flex items-end space-x-4">
                <div className="space-y-2">
                  <Label htmlFor="startingEquity" className="text-cyan-300">
                    Starting Equity
                  </Label>
                  <Input
                    id="startingEquity"
                    type="number"
                    value={startingEquity}
                    onChange={(e) => setStartingEquity(Number(e.target.value))}
                    className="cyber-input w-28"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="maxIterations" className="text-cyan-300">
                    Max Iterations
                  </Label>
                  <Input
                    id="maxIterations"
                    type="number"
                    value={maxIterations}
                    onChange={(e) => setMaxIterations(Number(e.target.value))}
                    className="cyber-input w-28"
                  />
                </div>
                <Button onClick={handleBuildStrategy} disabled={isLoading} className="cyber-button">
                  <Code className="mr-2 h-4 w-4" />
                  Build Strategy
                </Button>
              </div>
            </div>
          </GlowCard>
        </motion.div>

        {/* AI Agents Conversation */}
        <motion.div variants={itemVariants}>
          <GlowCard variant="strategizer" glowIntensity="low" className="cyber-card">
            <motion.div
              className="flex items-center gap-2 mb-4"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Bot className="h-5 w-5 text-cyan-500" />
              <h2 className="text-lg font-semibold text-cyan-400">AI Agents Conversation</h2>
            </motion.div>
            <ScrollArea className="h-[200px] rounded-md border border-cyan-800">
              <AnimatePresence>
                {messages.map((conversation, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.3 }}
                    className="p-2 text-cyan-300"
                  >
                    <span className="font-semibold text-cyan-400">{conversation.agent}:</span> {conversation.message}
                  </motion.div>
                ))}
              </AnimatePresence>
            </ScrollArea>
          </GlowCard>
        </motion.div>

        {/* Strategy Output */}
        {strategy && (
          <motion.div variants={itemVariants} initial="hidden" animate="visible" exit="hidden">
            <GlowCard variant="strategizer" glowIntensity="high" className="cyber-card">
              <motion.div
                className="flex items-center gap-2 mb-4"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Code className="h-5 w-5 text-cyan-500" />
                <h2 className="text-lg font-semibold text-cyan-400">Generated Strategy</h2>
              </motion.div>
              <div className="space-y-4">
                <motion.div
                  className="rounded-md border border-cyan-800 overflow-hidden"
                  variants={glowVariants}
                  whileHover="hover"
                  initial="idle"
                >
                  <SyntaxHighlighter language="python" style={dracula} className="max-h-[400px] overflow-auto">
                    {strategy}
                  </SyntaxHighlighter>
                </motion.div>
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button onClick={handleBacktest} disabled={isLoading} className="w-full cyber-button">
                    <PlayCircle className="mr-2 h-4 w-4" />
                    Run Backtest
                  </Button>
                </motion.div>
              </div>
            </GlowCard>
          </motion.div>
        )}

        {/* User Approval Modal */}
        <AnimatePresence>
          {userApprovalNeeded && approvalData && (
            <Modal title="AI Strategy Refinement Request" onClose={() => setUserApprovalNeeded(false)}>
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.3 }}
              >
                <GlowCard variant="rekt" glowIntensity="medium" className="cyber-card">
                  <p className="text-cyan-300">
                    The AI needs your approval to refine the strategy. Please review the following:
                  </p>
                  <pre className="bg-blue-950/40 p-4 rounded-md text-cyan-300 mt-2">
                    {JSON.stringify(approvalData, null, 2)}
                  </pre>
                  <Button onClick={() => setUserApprovalNeeded(false)} className="mt-4 cyber-button">
                    Approve
                  </Button>
                </GlowCard>
              </motion.div>
            </Modal>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  )
}
