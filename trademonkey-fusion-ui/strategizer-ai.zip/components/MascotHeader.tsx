"use client"

import { motion } from "framer-motion"
import { Image } from "./Image"

interface MascotHeaderProps {
  variant: "strategizer" | "rekt"
  title: string
  subtitle?: string
}

export function MascotHeader({ variant, title, subtitle }: MascotHeaderProps) {
  return (
    <motion.div
      className="relative flex items-center gap-4 overflow-hidden rounded-lg bg-blue-950/40 p-4 border border-cyan-500/30 backdrop-blur-md"
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <motion.div className="relative h-20 w-20 shrink-0" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
        <Image
          src={
            variant === "strategizer"
              ? "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/stategizer_bunny_ai-iwHZmnexMKb7l3Sz72Gf1fFsLGOE6E.webp"
              : "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/rekt_rabbit-kcY1dZV7KgeDjgJZf04mc7rZHHwM58.webp"
          }
          alt={variant === "strategizer" ? "Strategizer Bunny" : "Rekt Rabbit"}
          fill
          className="object-cover rounded-lg"
        />
      </motion.div>
      <div className="space-y-1">
        <motion.h2
          className={`text-2xl font-bold cyber-glitch ${variant === "strategizer" ? "text-cyan-400" : "text-pink-400"}`}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          {title}
        </motion.h2>
        {subtitle && (
          <motion.p
            className="text-cyan-300"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            {subtitle}
          </motion.p>
        )}
      </div>
    </motion.div>
  )
}
