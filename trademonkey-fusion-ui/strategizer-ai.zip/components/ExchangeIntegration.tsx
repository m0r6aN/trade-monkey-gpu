"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/useToast"
import { connectExchange } from "@/api/exchanges"
import { motion } from "framer-motion"

const exchanges = ["Alpaca"]

export function ExchangeIntegration() {
  const [selectedExchange, setSelectedExchange] = useState("")
  const [apiKey, setApiKey] = useState("")
  const [apiSecret, setApiSecret] = useState("")
  const { toast } = useToast()

  const handleConnect = async () => {
    if (!selectedExchange || !apiKey || !apiSecret) {
      toast({ title: "Error", description: "Please fill in all fields", variant: "destructive" })
      return
    }

    try {
      await connectExchange(selectedExchange, apiKey, apiSecret)
      toast({ title: "Success", description: `Connected to ${selectedExchange} successfully` })
      setApiKey("")
      setApiSecret("")
    } catch (error) {
      toast({ title: "Error", description: (error as Error).message, variant: "destructive" })
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="p-6 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-950 via-background to-background min-h-screen"
    >
      <h1 className="text-3xl font-bold text-cyan-400 mb-6">Exchange Integration</h1>
      <Card className="cyber-card bg-blue-950/40 backdrop-blur-md border-cyan-500/30">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-center text-cyan-500 cyber-glitch">
            CONNECT TO EXCHANGE
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="exchange" className="text-cyan-300">
              Select Exchange
            </Label>
            <Select onValueChange={setSelectedExchange}>
              <SelectTrigger id="exchange" className="cyber-input">
                <SelectValue placeholder="Select an exchange" />
              </SelectTrigger>
              <SelectContent className="bg-blue-950 border-cyan-500">
                {exchanges.map((exchange) => (
                  <SelectItem key={exchange} value={exchange} className="text-cyan-300 hover:bg-cyan-900/30">
                    {exchange}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="apiKey" className="text-cyan-300">
              API Key
            </Label>
            <Input
              id="apiKey"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder="Enter your API key"
              className="cyber-input"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="apiSecret" className="text-cyan-300">
              API Secret
            </Label>
            <Input
              id="apiSecret"
              type="password"
              value={apiSecret}
              onChange={(e) => setApiSecret(e.target.value)}
              placeholder="Enter your API secret"
              className="cyber-input"
            />
          </div>
          <Button onClick={handleConnect} className="w-full cyber-button">
            Connect
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  )
}
