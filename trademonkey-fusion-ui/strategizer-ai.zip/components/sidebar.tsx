"use client"

import { Home, MessageSquare, Cpu, ShieldCheck, BrainCircuit, ActivitySquare, Code } from "lucide-react"
import { useLocation } from "react-router-dom"
import { motion } from "framer-motion"

const navItems = [
  { icon: Home, label: "Command Center", href: "/" },
  { icon: Cpu, label: "AI Strategy Builder", href: "/strategy-builder" },
  { icon: ShieldCheck, label: "Risk Management", href: "/rekt-rabbit" },
  { icon: BrainCircuit, label: "Market Intelligence", href: "/strategizer-bunny" },
  { icon: ActivitySquare, label: "Backtesting & Analytics", href: "/backtesting" },
  { icon: Code, label: "Custom Tools & APIs", href: "/cipher-lab" },
  { icon: MessageSquare, label: "AI Chat", href: "/chat" },
]

export function Sidebar() {
  const location = useLocation()

  return (
    <motion.div
      initial={{ opacity: 0, x: -100 }}
      animate={{ opacity: 1, x: 0 }}
      className="fixed left-0 top-0 bottom-0 z-50 p-4 flex items-center"
    >
      <nav className="flex flex-col items-start space-y-4">
        {navItems.map((item, index) => (
          <motion.a
            key={item.href}
            href={item.href}
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="cyber-nav-icon group"
            data-active={location.pathname === item.href}
          >
            <item.icon className="w-6 h-6" />
            <span className="cyber-nav-label">{item.label}</span>
          </motion.a>
        ))}
      </nav>
    </motion.div>
  )
}
