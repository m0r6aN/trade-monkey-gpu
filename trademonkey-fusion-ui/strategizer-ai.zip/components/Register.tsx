"use client"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { useNavigate } from "react-router-dom"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { useToast } from "@/hooks/useToast"
import { UserPlus, Shield, Terminal } from "lucide-react"
import { useAuth } from "@/contexts/AuthContext"

type RegisterForm = {
  email: string
  password: string
}

export function Register() {
  const [loading, setLoading] = useState(false)
  const { toast } = useToast()
  const { register: registerUser } = useAuth()
  const navigate = useNavigate()
  const { register, handleSubmit } = useForm<RegisterForm>()

  const onSubmit = async (data: RegisterForm) => {
    try {
      setLoading(true)
      await registerUser(data.email, data.password)
      toast({
        title: "Access Granted",
        description: "New credentials successfully registered",
      })
      navigate("/login")
    } catch (error: any) {
      console.log("Register error:", error)
      toast({
        variant: "destructive",
        title: "Registration Failed",
        description: error?.message,
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-950 via-background to-background p-4 relative overflow-hidden">
      {/* Matrix-like background effect */}
      <div className="absolute inset-0 overflow-hidden opacity-20">
        {Array.from({ length: 10 }).map((_, i) => (
          <div
            key={i}
            className="absolute text-xs text-cyan-500 whitespace-nowrap"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animation: `float-down ${Math.random() * 5 + 5}s linear infinite`,
            }}
          >
            {Array.from({ length: 20 })
              .map(() => Math.random().toString(16).substr(-1))
              .join("")}
          </div>
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <Card className="cyber-card bg-blue-950/40 backdrop-blur-md border-cyan-500/30">
          <CardHeader className="relative z-10 space-y-1">
            <div className="flex items-center justify-center mb-2 text-cyan-500">
              <Terminal className="w-6 h-6 mr-2" />
              <Shield className="w-6 h-6" />
            </div>
            <CardTitle className="text-2xl font-bold text-center text-cyan-500 cyber-glitch">
              NEW USER REGISTRATION
            </CardTitle>
            <CardDescription className="text-center text-cyan-300/70">
              Initializing secure credential creation protocol...
            </CardDescription>
          </CardHeader>
          <CardContent className="relative z-10">
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-cyan-300">
                  PRIMARY ACCESS ID
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="Enter your access identifier"
                  {...register("email", { required: true })}
                  className="cyber-input"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password" className="text-cyan-300">
                  ENCRYPTION KEY
                </Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Generate secure key"
                  {...register("password", { required: true })}
                  className="cyber-input"
                />
              </div>
              <Button type="submit" className="w-full cyber-button" disabled={loading}>
                {loading ? (
                  "INITIALIZING..."
                ) : (
                  <>
                    <UserPlus className="mr-2 h-4 w-4" />
                    GENERATE CREDENTIALS
                  </>
                )}
              </Button>
            </form>
          </CardContent>
          <CardFooter className="flex justify-center relative z-10">
            <Button
              variant="link"
              className="text-sm text-cyan-300 hover:text-cyan-400"
              onClick={() => navigate("/login")}
            >
              RETURN TO AUTHENTICATION PORTAL
            </Button>
          </CardFooter>
          <div className="absolute top-0 left-0 p-2 text-xs text-cyan-500/50 font-mono">SEC::v1.0.2</div>
          <div className="absolute top-0 right-0 p-2 text-xs text-cyan-500/50 font-mono">
            {new Date().toISOString().split("T")[0]}
          </div>
        </Card>
      </motion.div>
    </div>
  )
}
