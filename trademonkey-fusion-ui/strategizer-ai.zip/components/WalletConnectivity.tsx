"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/useToast"
import { connectWallet } from "@/api/wallets"
import { motion } from "framer-motion"

export function WalletConnectivity() {
  const [walletAddress, setWalletAddress] = useState("")
  const { toast } = useToast()

  const handleConnect = async () => {
    if (!walletAddress) {
      toast({ title: "Error", description: "Please enter a wallet address", variant: "destructive" })
      return
    }

    try {
      await connectWallet(walletAddress)
      toast({ title: "Success", description: "Wallet connected successfully" })
      setWalletAddress("")
    } catch (error) {
      toast({ title: "Error", description: error.message, variant: "destructive" })
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="p-6 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-950 via-background to-background min-h-screen"
    >
      <h1 className="text-3xl font-bold text-cyan-400 mb-6">Wallet Connectivity</h1>
      <Card className="cyber-card bg-blue-950/40 backdrop-blur-md border-cyan-500/30">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-center text-cyan-500 cyber-glitch">CONNECT WALLET</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="walletAddress" className="text-cyan-300">
              Wallet Address
            </Label>
            <Input
              id="walletAddress"
              value={walletAddress}
              onChange={(e) => setWalletAddress(e.target.value)}
              placeholder="Enter your wallet address"
              className="cyber-input"
            />
          </div>
          <Button onClick={handleConnect} className="w-full cyber-button">
            Connect Wallet
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  )
}
